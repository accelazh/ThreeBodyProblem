package com.jme.util.export;

public interface ReadListener {

    public void readBytes(int bytes);
    
}
