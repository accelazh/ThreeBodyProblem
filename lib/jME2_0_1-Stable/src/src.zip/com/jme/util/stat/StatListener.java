package com.jme.util.stat;

public interface StatListener {

    public void statsUpdated();
    
}
